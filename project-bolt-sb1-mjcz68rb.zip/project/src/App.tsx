import React, { useState } from 'react';
import { Copy, Heart } from 'lucide-react';

function App() {
  const [copied, setCopied] = useState(false);
  const iban = 'IT02V0538715700000003526189';

  const copyIban = async () => {
    try {
      await navigator.clipboard.writeText(iban);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5DC] text-gray-800">
      {/* Header */}
      <header className="relative py-20 text-center bg-gradient-to-b from-[#F5F5DC] to-white">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1511795409834-ef04bbd61622?q=80&w=3869&auto=format&fit=crop')] opacity-10 bg-cover bg-center" />
        </div>
        <div className="relative z-10">
          <h1 className="font-serif text-6xl md:text-7xl mb-4">Luca & Andrea Veruska</h1>
          <p className="text-xl md:text-2xl mb-2 font-serif">21 Settembre 2025</p>
          <p className="text-lg md:text-xl text-[#808000] mb-1">Casa Freda, Foggia</p>
          <p className="text-lg md:text-xl text-[#808000]">Ore 17:00</p>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative max-w-6xl mx-auto px-4 py-16">
        <div className="relative rounded-lg overflow-hidden shadow-2xl">
          <iframe 
            src="https://drive.google.com/file/d/1lOPgIBzcJfqlk_ZBjdLqbtRFfXM_U4px/preview" 
            width="100%" 
            height="600" 
            allow="autoplay"
            className="w-full"
          ></iframe>
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        </div>
      </section>

      {/* RSVP Section */}
      <section className="bg-white py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="font-serif text-4xl mb-8 text-[#808000]">Conferma la tua presenza</h2>
          <div className="flex flex-col items-center">
            <a
              href="https://docs.google.com/forms/d/e/1FAIpQLSdmJy9W4ixamNjb9GLZiVn_i-SRf63_9SYTAqpQJ_PAzDR_iQ/viewform?usp=dialog"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-[#808000] text-white px-8 py-4 rounded-lg text-xl font-semibold transition-transform hover:scale-105 hover:shadow-lg"
            >
              Conferma Qui
            </a>
            <p className="mt-6 text-lg text-gray-600">Clicca il pulsante per confermare la tua partecipazione</p>
          </div>
        </div>
      </section>

      {/* Gift Registry Section */}
      <section className="py-16 bg-[#F5F5DC]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="font-serif text-4xl mb-8 text-[#808000]">Regalo di Nozze</h2>
          <p className="text-lg mb-8">La vostra presenza al nostro matrimonio è il regalo più grande. Tuttavia se desiderate onorarci con un contributo per il nostro viaggio di nozze sarà profondamente apprezzato.</p>
          
          <div className="bg-white rounded-lg p-8 shadow-lg max-w-2xl mx-auto">
            <p className="text-xl mb-4 font-semibold">Coordinate Bancarie</p>
            <div className="flex items-center justify-center space-x-2 mb-4">
              <p className="text-lg font-mono">{iban}</p>
              <button
                onClick={copyIban}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                title="Copia IBAN"
              >
                <Copy className="w-5 h-5 text-[#808000]" />
              </button>
            </div>
            {copied && (
              <p className="text-[#808000] text-sm">IBAN copiato negli appunti!</p>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#808000] text-white py-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex justify-center items-center space-x-2 mb-4">
            <Heart className="w-5 h-5" />
            <span>Luca & Andrea Veruska</span>
            <Heart className="w-5 h-5" />
          </div>
          <p className="text-sm opacity-80">© 2025 Matrimonio di Luca & Andrea Veruska. Tutti i diritti riservati.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;